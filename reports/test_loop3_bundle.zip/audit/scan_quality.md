# Quantitative Scanner Quality & Lineage Report

**Scan ID:** `SCAN_2026-10-16_1792364073`  
**Execution Timestamp:** 2026-10-18 22:54:33  
**As-Of Market Date:** 2026-10-16  
**Reference Benchmark:** `UNIVERSE_PROXY`  
**Strategy Version:** `MIP-Scanner-1.0`  
**Scanner Version:** `2.0.0-institutional`  
**Configuration Hash:** `6c8981f97b010ad4...`  
**Execution Runtime:** 18.63s  

---

## 1. Scanner Health State: **BLOCKED**

- **Allow Actionable Buys:** `False`
- **Universe Coverage:** 92.0% (46 / 50 symbols)
- **Benchmark Status:** `STALE` (Regime: `STALE`)

### Next-Gen Alpha Overlays & Risk Controls:

| Overlay Dimension | Status | Formulation / Reference |
|---|---|---|
| **Residual Momentum** | `ACTIVE` | Blitz et al. (2011) 40% Volar / 60% Idiosyncratic Alpha |
| **Dynamic Volatility Cash Shield** | `ACTIVE` | Harvey et al. (2018) 12% Realized Target Volatility |
| **Delivery Flow Absorption Veto** | `ACTIVE` | Microstructure Distribution Spikes Veto |

### Critical Health Blocking Reasons:
- ⚠️ Benchmark integrity failure: status is STALE

---

## 2. Quantitative Funnel & Reason Code Distribution

| Metric | Count | Percentage |
|---|---|---|
| **Requested Universe** | 50 | 100.0% |
| **Data-Valid Securities** | 46 | 92.0% |
| **Qualified Strategy Candidates** | 11 | 22.0% |
| **Excluded / Failed Securities** | 39 | 78.0% |

### Reason Code Histogram:

| Reason Code | Count | Category | Description |
|---|---|---|---|
| `BELOW_52W_HIGH_THRESHOLD` | 23 | STRATEGY_FILTER | Close is below 80% of 52-week rolling high. |
| `PASS` | 11 | SUCCESS | Candidate fully qualified and verified across all strategy rules. |
| `BELOW_EMA200` | 8 | STRATEGY_FILTER | Close is not strictly above the 200-day exponential moving average. |
| `INSUFFICIENT_HISTORY` | 4 | HISTORY | History is below mandatory 252-session minimum. |
| `NEGATIVE_MOMENTUM` | 4 | STRATEGY_FILTER | 1-year momentum return or Volar score is non-positive. |

---

## 3. Top Qualified Candidates

| Rank | Symbol | Sector | Close (₹) | Volar | Res Alpha | 1Y Return | Delivery Action | Status |
|---|---|---|---|---|---|---|---|---|
| 1 | **DIVISLAB** | HEALTHCARE | ₹9,144.50 | `1.24` | `+0.907` | +40.1% | APPROVED | PASS |
| 2 | **ABB** | CAPITAL GOODS | ₹6,801.00 | `0.86` | `+0.681` | +35.0% | APPROVED | PASS |
| 3 | **SOLARINDS** | CHEMICALS | ₹20,011.00 | `0.75` | `+0.458` | +43.0% | APPROVED | PASS |
| 4 | **MOTHERSON** | AUTOMOBILE AND AUTO COMPONENTS | ₹160.00 | `0.70` | `+0.121` | +53.0% | APPROVED | PASS |
| 5 | **TORNTPHARM** | HEALTHCARE | ₹4,558.90 | `0.70` | `+0.241` | +30.6% | APPROVED | PASS |
| 6 | **SIEMENS** | CAPITAL GOODS | ₹3,624.00 | `0.34` | `+0.167` | +18.3% | APPROVED | PASS |
| 7 | **UNIONBANK** | FINANCIAL SERVICES | ₹171.68 | `0.28` | `-0.119` | +29.0% | APPROVED | PASS |
| 8 | **BOSCHLTD** | AUTOMOBILE AND AUTO COMPONENTS | ₹45,560.00 | `0.16` | `-0.169` | +19.0% | APPROVED | PASS |